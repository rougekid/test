$ pyuicfg -g --pyqt5
pyuic.json generated
$ cat pyuic.json
{
    "files": [],
    "hooks": [],
    "pyrcc": "pyrcc5",
    "pyrcc_options": "",
    "pyuic": "pyuic5",
    "pyuic_options": "--from-import"
}